# MAXX Rooms Hotel Website Requirement Document

## 1. Website Naam
MAXX Rooms — Sarhaul, Gurugram

## 2. Website Description
Yehek hotel booking aur information website hai jo MAXX Rooms hotel ke liye banayi gayi hai. Website visitors ko hotel ki complete details, room types, booking facility, reviews, location map aur direct WhatsApp contact provide karti hai.

## 3. Website Ki Main Functionality
\n### 3.1 Hero Section
- Hotel ka naam aur tagline:'MAXX Rooms — Sarhaul (Sector 18), Gurugram'\n- Tagline: 'Comfortable stays for business & leisure — clean rooms, free Wi-Fi, in-house dining'
- Rating display: 4.5★ (aggregated)\n- Price range: Rooms from ₹1,200+\n- Amenities badges: Free Wi-Fi, Room service\n- Photo gallery links (Goibibo aur MakeMyTrip se)
- Complete address: Sector 18, Sarhaul, Gurugram, Haryana 122015

### 3.2 Quick Booking Panel
- Google Maps pe phone number dikhane ka button
- Goibibo pe direct booking link
- Interactive map preview (embedded Google Maps)
- Location: F3RC+7JM Maxx Rooms, near munjal company, Maruti Udyog, Sector 18, Gurugram

### 3.3 Reviews Section
- Top positive reviews ka rotating display (har6 seconds pe change)\n- Reviews sources: Goibibo, MakeMyTrip, JustDial
- Har review clickable hai aur source page pe le jata hai
- 'See all reviews on Maps' button

### 3.4 Mini Map Section
- Location quick view ke liye chhota embedded map
- Click karne pe full Google Maps khulta hai
\n### 3.5 Booking Request Form (WhatsApp Integration)
Form fields:
- Full name (required)
- Phone/WhatsApp number (required)
- Check-in aur Check-out dates (required)
- Room type selection: Deluxe, Superior\n- Special requests (optional textarea)
- Submit karne pe WhatsApp khulta hai with pre-filled message
- Message format: Booking request with name, phone, dates, room type, special requests

### 3.6 Contact Us Form (WhatsApp Integration)
Form fields:
- Full name (required)\n- Phone/WhatsApp number (required)
- Message (textarea)\n- Submit karne pe WhatsApp khulta hai with pre-filled contact message
\n### 3.7 Contact Information Section
- Owner WhatsApp number display
- Google Maps link for calls aur full listing
\n### 3.8 Floating WhatsApp Button
- Fixed position (bottom-right corner)
- Green circular button with WhatsApp icon
- Click karne pe owner ke WhatsApp pe inquiry message bhejta hai

## 4. Technical Configuration

### 4.1 WhatsApp Integration
- Owner WhatsApp number: 919999999999 (placeholder - replace karna hai)
- Sare forms aur buttons is number pe messages bhejte hain
\n### 4.2 Google Maps Integration
- Place URL: https://www.google.com/maps/place/F3RC%2B7JM+Maxx+Rooms,+near+munjal+company,+Maruti+Udyog,+Sector+18,+Gurugram,+Sarhol,+Haryana+122015\n- Embed query: F3RC%2B7JM%20Maxx%20Rooms%20Sarhaul%20Gurugram
- Do embedded maps:ek bada (320px height) aur ek chhota (140px height)\n
### 4.3 External Booking Links
- Goibibo: https://www.goibibo.com/hotels/maxx-rooms-hotel-in-gurgaon-6493610740515855306/
- MakeMyTrip: https://www.makemytrip.com/hotels/maxx_rooms-details-gurgaon.html
- JustDial: https://www.justdial.com/Gurgaon/Maxx-Rooms-Sarhaul/011PXX11-XX11-240730160335-R4B9_BZDET

### 4.4 Sample Reviews Content
1. 'Value for money — clean rooms, quick service and friendly staff. Stayed for business — location is convenient.' — Guest (Goibibo)
2. 'Room was well maintained and housekeeping did a good job. Food available and staff helpful for local guidance.' — Traveller (MakeMyTrip)
3. 'Good budget option near industrial areas — easy access to offices and transit.' — Reviewer (JustDial)
\n## 5. Website Design Style

### 5.1 Color Scheme
- Primary accent color: #0b6efd (bright blue)
- Background: #f7f7f8 (light gray)
- Card background: #fff (white)
- Muted text: #6b6b6b (gray)
- Badge backgrounds: #eef5ff (light blue), #fff6ef (light orange), #eef7ec (light green)
- WhatsApp green: #25D366\n
### 5.2 Layout Style
- Clean card-based layout with subtle shadows (06px 18px rgba)\n- Responsive grid system (desktop: 2-column, mobile: single column)
- Maximum content width: 1100px
- Border radius: 8-12px for cards and buttons

### 5.3 Typography
- Font family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial\n- Heading sizes: H1 (26px), H3 (default)\n- Body text: default size with clear hierarchy
\n### 5.4 Interactive Elements
- Buttons: Blue (#0b6efd) with white text,10px padding, rounded corners
- Form inputs: White background, light border (#e6e6e9), 8px border radius
- Hover effects: Smooth transitions\n- Floating WhatsApp button: 56x56px circular, green with shadow

### 5.5 Visual Components
- Gallery grid: Auto-fit columns (minimum 140px)
- Image thumbnails: 110x80px for rooms, 110px height for gallery
- Badges: Rounded pills with colored backgrounds
- Reviews: Gradient background cards with auto-rotation animation
\n## 6. Responsive Behavior
- Desktop: Two-column layout for main content
- Mobile (below 920px): Single column stack layout
- All images and maps:100% width with proper aspect ratios
- Touch-friendly buttons and form elements

## 7. Special Notes
- Website bilingual hai (English + Hindi/Hinglish mix)
- Sare external links new tab mein khulte hain
- Forms submit hone pe WhatsApp app automatically khulti hai
- Reviews har6 seconds mein rotate hote hain
- Owner number placeholder hai - actual number se replace karna zaroori hai