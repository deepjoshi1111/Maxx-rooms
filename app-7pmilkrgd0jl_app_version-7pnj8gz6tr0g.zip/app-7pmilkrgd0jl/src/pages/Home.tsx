import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import FloatingWhatsApp from "@/components/hotel/FloatingWhatsApp";
import ReviewCard from "@/components/hotel/ReviewCard";
import BookingForm from "@/components/hotel/BookingForm";
import ContactForm from "@/components/hotel/ContactForm";
import { Star, Wifi, UtensilsCrossed, MapPin, Phone, ExternalLink, Map, Award, Shield, Clock } from "lucide-react";

const WHATSAPP_NUMBER = "919999999999";

const HOTEL_INFO = {
  name: "MAXX Rooms",
  location: "Sarhaul (Sector 18), Gurugram",
  tagline: "Luxury Comfort for Business & Leisure Travelers",
  rating: 4.5,
  priceFrom: "₹1,200",
  address: "Sector 18, Sarhaul, Gurugram, Haryana 122015",
  mapLocation: "F3RC+7JM Maxx Rooms, near munjal company, Maruti Udyog, Sector 18, Gurugram",
  mapUrl: "https://www.google.com/maps/place/F3RC%2B7JM+Maxx+Rooms,+near+munjal+company,+Maruti+Udyog,+Sector+18,+Gurugram,+Sarhol,+Haryana+122015",
  embedQuery: "F3RC%2B7JM%20Maxx%20Rooms%20Sarhaul%20Gurugram",
};

const BOOKING_LINKS = {
  goibibo: "https://www.goibibo.com/hotels/maxx-rooms-hotel-in-gurgaon-6493610740515855306/",
  makemytrip: "https://www.makemytrip.com/hotels/maxx_rooms-details-gurgaon.html",
  justdial: "https://www.justdial.com/Gurgaon/Maxx-Rooms-Sarhaul/011PXX11-XX11-240730160335-R4B9_BZDET",
};

const REVIEWS = [
  {
    text: "Exceptional value for money! The rooms are spotlessly clean with modern amenities. Staff is incredibly helpful and the location is perfect for business travelers.",
    author: "Business Traveler",
    source: "Goibibo",
    sourceUrl: BOOKING_LINKS.goibibo,
    rating: 5,
  },
  {
    text: "Beautifully maintained property with elegant interiors. The housekeeping team does an outstanding job. Highly recommend for both short and extended stays.",
    author: "Verified Guest",
    source: "MakeMyTrip",
    sourceUrl: BOOKING_LINKS.makemytrip,
    rating: 4,
  },
  {
    text: "Perfect budget hotel near industrial areas with easy access to major offices. Clean rooms, comfortable beds, and excellent service make it a great choice.",
    author: "Corporate Guest",
    source: "JustDial",
    sourceUrl: BOOKING_LINKS.justdial,
    rating: 4,
  },
];

const ROOM_IMAGES = {
  deluxeTwin: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7p2ar2bnbx8g/conv-7pmilkrgd0jk/20251121/file-7pn6ia0t6igw.png",
  deluxeKing: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7p2ar2bnbx8g/conv-7pmilkrgd0jk/20251121/file-7pn6ia0t6osg.png",
  superiorRoom1: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7p2ar2bnbx8g/conv-7pmilkrgd0jk/20251121/file-7pn6dw6c5y4g.png",
  superiorRoom2: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7p2ar2bnbx8g/conv-7pmilkrgd0jk/20251121/file-7pn6dw6c6h34.png",
  twinRoom: "https://miaoda-conversation-file.s3cdn.medo.dev/user-7p2ar2bnbx8g/conv-7pmilkrgd0jk/20251121/file-7pn6ipt22ry8.png",
};

export default function Home() {
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentReviewIndex((prev) => (prev + 1) % REVIEWS.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const handlePhoneClick = () => {
    window.open(HOTEL_INFO.mapUrl, "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/30">
      <FloatingWhatsApp phoneNumber={WHATSAPP_NUMBER} />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-primary/10">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmYWNjMTUiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE4YzAtOS45NC04LjA2LTE4LTE4LTE4UzAgOC4wNiAwIDE4czguMDYgMTggMTggMTggMTgtOC4wNiAxOC0xOHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-40"></div>
        
        <div className="relative mx-auto max-w-7xl px-4 py-12 xl:px-8 xl:py-20">
          <div className="grid gap-8 xl:grid-cols-2 xl:gap-12">
            {/* Hero Image */}
            <div className="relative overflow-hidden rounded-2xl shadow-luxury">
              <img
                src={ROOM_IMAGES.deluxeKing}
                alt="MAXX Rooms Luxury Hotel"
                className="h-[400px] w-full object-cover xl:h-[500px]"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                <div className="flex items-center gap-2 text-white">
                  <Award className="h-5 w-5 text-primary" />
                  <span className="text-sm font-medium">Premium Hospitality Since 2020</span>
                </div>
              </div>
            </div>

            {/* Hero Content */}
            <div className="flex flex-col justify-center">
              <div className="mb-6">
                <h1 className="mb-3 text-4xl font-bold leading-tight text-foreground xl:text-5xl">
                  {HOTEL_INFO.name}
                </h1>
                <p className="mb-2 flex items-center gap-2 text-lg text-muted-foreground">
                  <MapPin className="h-5 w-5 text-primary" />
                  {HOTEL_INFO.location}
                </p>
                <p className="text-xl text-muted-foreground">{HOTEL_INFO.tagline}</p>
              </div>

              <div className="mb-6 flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(HOTEL_INFO.rating)
                          ? "fill-primary text-primary"
                          : "fill-muted text-muted"
                      }`}
                    />
                  ))}
                  <span className="ml-1 font-semibold text-foreground">{HOTEL_INFO.rating}</span>
                </div>
                <div className="rounded-full bg-primary px-6 py-2 font-semibold text-primary-foreground">
                  From {HOTEL_INFO.priceFrom}/night
                </div>
              </div>

              <div className="mb-8 flex flex-wrap gap-3">
                <Badge className="badge-gold gap-2 px-4 py-2 text-sm">
                  <Wifi className="h-4 w-4" />
                  Free High-Speed Wi-Fi
                </Badge>
                <Badge className="badge-blue gap-2 px-4 py-2 text-sm">
                  <UtensilsCrossed className="h-4 w-4" />
                  24/7 Room Service
                </Badge>
                <Badge className="badge-green gap-2 px-4 py-2 text-sm">
                  <Shield className="h-4 w-4" />
                  Secure & Sanitized
                </Badge>
              </div>

              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="gap-2 shadow-lg" onClick={handlePhoneClick}>
                  <Phone className="h-5 w-5" />
                  View on Google Maps
                </Button>
                <Button size="lg" variant="outline" className="gap-2" asChild>
                  <a href={BOOKING_LINKS.goibibo} target="_blank" rel="noopener noreferrer">
                    Book Now
                    <ExternalLink className="h-5 w-5" />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12 xl:px-8">
        {/* Features Section */}
        <section className="mb-16">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="border-primary/20 shadow-elegant transition-smooth hover:shadow-luxury">
              <CardContent className="flex flex-col items-center p-8 text-center">
                <div className="mb-4 rounded-full bg-primary/10 p-4">
                  <Clock className="h-8 w-8 text-primary" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">24/7 Service</h3>
                <p className="text-muted-foreground">Round-the-clock assistance for all your needs</p>
              </CardContent>
            </Card>
            <Card className="border-primary/20 shadow-elegant transition-smooth hover:shadow-luxury">
              <CardContent className="flex flex-col items-center p-8 text-center">
                <div className="mb-4 rounded-full bg-primary/10 p-4">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Safe & Secure</h3>
                <p className="text-muted-foreground">Fully sanitized rooms with modern security</p>
              </CardContent>
            </Card>
            <Card className="border-primary/20 shadow-elegant transition-smooth hover:shadow-luxury">
              <CardContent className="flex flex-col items-center p-8 text-center">
                <div className="mb-4 rounded-full bg-primary/10 p-4">
                  <Award className="h-8 w-8 text-primary" />
                </div>
                <h3 className="mb-2 text-xl font-semibold">Premium Quality</h3>
                <p className="text-muted-foreground">Luxury amenities at affordable prices</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Photo Gallery */}
        <section className="mb-16">
          <div className="mb-8 text-center">
            <h2 className="mb-3 text-3xl font-bold text-foreground">Our Rooms & Suites</h2>
            <p className="text-lg text-muted-foreground">Experience comfort and elegance in every detail</p>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:gap-6">
            {[
              { img: ROOM_IMAGES.deluxeTwin, title: "Deluxe Twin Room", link: BOOKING_LINKS.goibibo },
              { img: ROOM_IMAGES.deluxeKing, title: "Deluxe King Suite", link: BOOKING_LINKS.goibibo },
              { img: ROOM_IMAGES.superiorRoom1, title: "Superior Room", link: BOOKING_LINKS.makemytrip },
              { img: ROOM_IMAGES.superiorRoom2, title: "Premium Suite", link: BOOKING_LINKS.makemytrip },
              { img: ROOM_IMAGES.twinRoom, title: "Executive Twin", link: BOOKING_LINKS.justdial },
              { img: ROOM_IMAGES.deluxeTwin, title: "Luxury Interior", link: BOOKING_LINKS.goibibo },
            ].map((room, index) => (
              <a
                key={index}
                href={room.link}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative overflow-hidden rounded-xl shadow-elegant transition-smooth hover:shadow-luxury"
              >
                <img
                  src={room.img}
                  alt={room.title}
                  className="h-56 w-full object-cover transition-smooth group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 transition-smooth group-hover:opacity-100"></div>
                <div className="absolute bottom-0 left-0 right-0 translate-y-full p-4 transition-smooth group-hover:translate-y-0">
                  <h3 className="text-lg font-semibold text-white">{room.title}</h3>
                  <p className="text-sm text-white/80">View Details →</p>
                </div>
              </a>
            ))}
          </div>
        </section>

        {/* Guest Reviews */}
        <section className="mb-16">
          <div className="mb-8 flex flex-col items-center justify-between gap-4 text-center md:flex-row md:text-left">
            <div>
              <h2 className="mb-2 text-3xl font-bold text-foreground">Guest Reviews</h2>
              <p className="text-lg text-muted-foreground">What our guests say about their experience</p>
            </div>
            <Button variant="outline" className="gap-2" asChild>
              <a href={HOTEL_INFO.mapUrl} target="_blank" rel="noopener noreferrer">
                View All Reviews
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>
          <div className="relative">
            <ReviewCard {...REVIEWS[currentReviewIndex]} />
            <div className="mt-6 flex justify-center gap-2">
              {REVIEWS.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentReviewIndex(index)}
                  className={`h-2 rounded-full transition-all ${
                    index === currentReviewIndex ? "w-8 bg-primary" : "w-2 bg-muted"
                  }`}
                  aria-label={`View review ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Location */}
        <section className="mb-16">
          <div className="mb-8 text-center">
            <h2 className="mb-3 text-3xl font-bold text-foreground">Our Location</h2>
            <p className="text-lg text-muted-foreground">Conveniently located in the heart of Gurugram</p>
          </div>
          <Card className="overflow-hidden shadow-luxury">
            <CardContent className="p-0">
              <iframe
                src={`https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3508.5!2d77.04!3d28.44!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2s${HOTEL_INFO.embedQuery}!5e0!3m2!1sen!2sin!4v1234567890`}
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="MAXX Rooms Location"
              />
            </CardContent>
          </Card>
          <div className="mt-6 text-center">
            <Button size="lg" variant="outline" className="gap-2" asChild>
              <a href={HOTEL_INFO.mapUrl} target="_blank" rel="noopener noreferrer">
                <Map className="h-5 w-5" />
                Open in Google Maps
              </a>
            </Button>
          </div>
        </section>

        {/* Booking & Contact Forms */}
        <section className="mb-16">
          <div className="mb-8 text-center">
            <h2 className="mb-3 text-3xl font-bold text-foreground">Get in Touch</h2>
            <p className="text-lg text-muted-foreground">Book your stay or send us a message</p>
          </div>
          <div className="grid gap-8 xl:grid-cols-2">
            <BookingForm whatsappNumber={WHATSAPP_NUMBER} />
            <ContactForm whatsappNumber={WHATSAPP_NUMBER} />
          </div>
        </section>

        {/* Contact CTA */}
        <section className="mb-16">
          <Card className="overflow-hidden border-primary/20 shadow-luxury">
            <CardContent className="bg-gradient-to-br from-primary/10 via-background to-primary/5 p-12 text-center">
              <h2 className="mb-4 text-3xl font-bold text-foreground">Need Immediate Assistance?</h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Contact us directly on WhatsApp for instant support and booking confirmation
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button
                  size="lg"
                  className="gap-2 bg-whatsapp hover:bg-whatsapp/90"
                  onClick={() => window.open(`https://wa.me/${WHATSAPP_NUMBER}`, "_blank")}
                >
                  <Phone className="h-5 w-5" />
                  WhatsApp: +91 99999 99999
                </Button>
                <Button size="lg" variant="outline" className="gap-2" asChild>
                  <a href={HOTEL_INFO.mapUrl} target="_blank" rel="noopener noreferrer">
                    <MapPin className="h-5 w-5" />
                    View on Maps
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card/50 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center xl:px-8">
          <div className="mb-6">
            <h3 className="mb-2 text-2xl font-bold text-foreground">MAXX Rooms</h3>
            <p className="text-muted-foreground">{HOTEL_INFO.address}</p>
          </div>
          <div className="mb-6 flex flex-wrap justify-center gap-6">
            <a
              href={BOOKING_LINKS.goibibo}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary transition-smooth hover:text-primary/80"
            >
              Book on Goibibo
            </a>
            <span className="text-muted">•</span>
            <a
              href={BOOKING_LINKS.makemytrip}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary transition-smooth hover:text-primary/80"
            >
              Book on MakeMyTrip
            </a>
            <span className="text-muted">•</span>
            <a
              href={BOOKING_LINKS.justdial}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary transition-smooth hover:text-primary/80"
            >
              View on JustDial
            </a>
          </div>
          <p className="text-sm text-muted-foreground">2025 MAXX Rooms. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
