import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";

interface ReviewCardProps {
  text: string;
  author: string;
  source: string;
  sourceUrl: string;
  rating?: number;
}

export default function ReviewCard({ text, author, source, sourceUrl, rating = 5 }: ReviewCardProps) {
  return (
    <a
      href={sourceUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="block transition-smooth hover:scale-[1.02]"
    >
      <Card className="h-full bg-gradient-to-br from-card to-secondary p-6 shadow-card">
        <div className="mb-3 flex items-center gap-1">
          {Array.from({ length: rating }).map((_, i) => (
            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          ))}
        </div>
        <p className="mb-4 text-sm leading-relaxed text-foreground">{text}</p>
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="font-medium">{author}</span>
          <span className="text-primary">{source}</span>
        </div>
      </Card>
    </a>
  );
}
