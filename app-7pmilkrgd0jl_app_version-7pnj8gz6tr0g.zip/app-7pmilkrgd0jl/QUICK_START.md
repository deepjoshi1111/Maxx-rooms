# MAXX Rooms Website - Quick Start Guide

## 🚀 Getting Started

Your MAXX Rooms hotel website is complete and ready to use! Follow these simple steps to get it running.

## ⚠️ IMPORTANT: Before Deployment

### Update WhatsApp Number (REQUIRED)

1. Open the file: `src/pages/Home.tsx`
2. Find line 9: `const WHATSAPP_NUMBER = "919999999999";`
3. Replace with your actual WhatsApp number (format: "91XXXXXXXXXX")

**Example:**
```typescript
// Before (placeholder)
const WHATSAPP_NUMBER = "919999999999";

// After (your actual number)
const WHATSAPP_NUMBER = "919876543210";
```

## 📋 What's Included

 **Hero Section** - Hotel name, rating, pricing, amenities
 **Photo Gallery** - 6 professional hotel images
 **Guest Reviews** - Auto-rotating reviews from booking platforms
 **Location Maps** - Embedded Google Maps (2 views)
 **Booking Form** - WhatsApp-integrated booking requests
 **Contact Form** - WhatsApp-integrated inquiries
 **Floating WhatsApp Button** - Always-visible contact button
 **Responsive Design** - Works perfectly on mobile and desktop
 **External Links** - Goibibo, MakeMyTrip, JustDial integration

## 🎨 Customization (Optional)

All content is in `src/pages/Home.tsx`. You can easily update:

### Hotel Information
```typescript
const HOTEL_INFO = {
  name: "MAXX Rooms",
  location: "Sarhaul (Sector 18), Gurugram",
  rating: 4.5,  // Change rating here
  priceFrom: "₹1,200",  // Update pricing here
  // ... more fields
};
```

### Reviews
```typescript
const REVIEWS = [
  {
    text: "Your review text here",
    author: "Guest Name",
    source: "Platform Name",
    sourceUrl: "https://...",
    rating: 5,
  },
  // Add more reviews...
];
```

### Images
```typescript
const ROOM_IMAGES = {
  deluxe: "https://...",  // Replace with your image URLs
  superior: "https://...",
  // ... more images
};
```

## 🔗 External Links

All external links are configured in `BOOKING_LINKS`:
- Goibibo booking page
- MakeMyTrip listing
- JustDial profile
- Google Maps location

## 📱 Features Overview

### For Visitors
- **View hotel information** - Name, location, rating, pricing
- **Browse photo gallery** - 6 high-quality images
- **Read guest reviews** - Real reviews from booking platforms
- **See location on map** - Interactive Google Maps
- **Request booking** - Fill form, submit via WhatsApp
- **Contact hotel** - Send inquiry via WhatsApp
- **Quick WhatsApp access** - Floating button always visible

### For Hotel Owners
- **Receive booking requests** - Formatted WhatsApp messages
- **Get contact inquiries** - Direct WhatsApp communication
- **Track visitor interest** - WhatsApp conversation history
- **Easy content updates** - All content in one file
- **No backend needed** - Simple, maintenance-free

## 🎯 How It Works

### Booking Process
1. Visitor fills booking form (name, phone, dates, room type)
2. Clicks "Send Booking Request via WhatsApp"
3. WhatsApp opens with pre-filled message
4. Message sent to your WhatsApp number
5. You receive formatted booking request
6. You respond directly on WhatsApp

### Contact Process
1. Visitor fills contact form (name, phone, message)
2. Clicks "Send Message via WhatsApp"
3. WhatsApp opens with pre-filled inquiry
4. Message sent to your WhatsApp number
5. You receive contact inquiry
6. You respond directly on WhatsApp

## 📊 Message Format Examples

### Booking Request Message
```
*Booking Request - MAXX Rooms*

*Name:* John Doe
*Phone:* +91 98765 43210
*Check-in:* 2025-12-01
*Check-out:* 2025-12-03
*Room Type:* Deluxe Room
*Special Requests:* Early check-in if possible

Please confirm availability and pricing.
```

### Contact Inquiry Message
```
*Contact Inquiry - MAXX Rooms*

*Name:* Jane Smith
*Phone:* +91 98765 43210

*Message:*
I would like to know about your long-term stay discounts.
```

## 🌐 Browser Support

Works perfectly on:
- ✅ Chrome (desktop & mobile)
- ✅ Safari (desktop & mobile)
- ✅ Firefox
- ✅ Edge
- ✅ All modern mobile browsers

## 📱 Mobile Experience

The website is fully optimized for mobile:
- Touch-friendly buttons and forms
- Responsive layouts (stacks on mobile)
- Easy-to-read text sizes
- Fast loading times
- Smooth animations

## 🔒 Privacy & Security

- No user data is stored on the website
- All communication happens via WhatsApp
- No cookies or tracking
- No backend database
- Simple and secure

## 🎨 Design Features

- **Modern UI** - Clean, professional design
- **Brand Colors** - Blue (#0b6efd) and WhatsApp green
- **Smooth Animations** - Hover effects and transitions
- **Card-Based Layout** - Organized, easy to scan
- **High-Quality Images** - Professional hotel photos
- **Clear CTAs** - Prominent action buttons

## 📈 Performance

- Fast loading times
- Optimized images
- Minimal JavaScript
- Efficient animations
- Mobile-optimized

## 🛠️ Technical Details

- **Framework:** React + TypeScript
- **Styling:** Tailwind CSS
- **UI Components:** shadcn/ui
- **Form Validation:** React Hook Form + Zod
- **Icons:** Lucide React
- **Build Tool:** Vite

## 📞 Support

If you need to update content:
1. Open `src/pages/Home.tsx`
2. Find the relevant section (HOTEL_INFO, REVIEWS, etc.)
3. Update the values
4. Save the file

## ✅ Pre-Deployment Checklist

Before launching:
- [ ] Update WhatsApp number in `src/pages/Home.tsx`
- [ ] Test booking form submission
- [ ] Test contact form submission
- [ ] Verify floating WhatsApp button works
- [ ] Check all external links (Goibibo, MakeMyTrip, JustDial)
- [ ] Verify Google Maps loads correctly
- [ ] Test on mobile device
- [ ] Test on desktop browser
- [ ] Confirm review rotation works
- [ ] Check all images load properly

## 🎉 You're Ready!

Your MAXX Rooms website is complete and ready to help you receive bookings and inquiries via WhatsApp!

**Remember:** The only required change before deployment is updating the WhatsApp number in `src/pages/Home.tsx`.

---

For detailed technical documentation, see `CONFIGURATION.md` and `WEBSITE_SUMMARY.md`.
