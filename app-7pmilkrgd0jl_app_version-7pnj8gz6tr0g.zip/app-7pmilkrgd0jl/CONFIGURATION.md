# MAXX Rooms Website Configuration

## Important: WhatsApp Number Configuration

**CRITICAL:** The WhatsApp number is currently set to a placeholder value and MUST be updated before deployment.

### Current Placeholder
```
919999999999
```

### How to Update

Open the file: `src/pages/Home.tsx`

Find line 9:
```typescript
const WHATSAPP_NUMBER = "919999999999";
```

Replace with your actual WhatsApp number in international format (without + or spaces):
```typescript
const WHATSAPP_NUMBER = "91XXXXXXXXXX";  // Replace with actual number
```

### WhatsApp Number Format
- Must be in international format
- No spaces, dashes, or special characters
- No leading + sign
- Example: For +91 98765 43210, use: "919876543210"

## Website Features

### 1. Hero Section
- Hotel name, location, and tagline
- Star rating (4.5★)
- Price range display
- Amenity badges (Free Wi-Fi, Room Service)
- Complete address
- Quick action buttons (View on Maps, Book on Goibibo)

### 2. Photo Gallery
- 6 high-quality hotel images
- Clickable images linking to booking platforms
- Hover effects for better user experience
- Categories: Deluxe Room, Superior Room, Workspace, Amenities, Lobby, Exterior

### 3. Guest Reviews
- Auto-rotating reviews (changes every 6 seconds)
- Reviews from Goibibo, MakeMyTrip, and JustDial
- Clickable to view full reviews on source platforms
- Visual indicators for current review

### 4. Location Maps
- Large interactive map (320px height)
- Mini map preview (140px height)
- Direct links to Google Maps
- Embedded Google Maps with full functionality

### 5. Booking Request Form
- Full name (required)
- Phone/WhatsApp number (required)
- Check-in date (required)
- Check-out date (required)
- Room type selection (Deluxe/Superior)
- Special requests (optional)
- Submits via WhatsApp with formatted message

### 6. Contact Form
- Full name (required)
- Phone/WhatsApp number (required)
- Message (required)
- Submits via WhatsApp with formatted message

### 7. Floating WhatsApp Button
- Fixed position at bottom-right
- Always visible while scrolling
- Direct WhatsApp inquiry link
- Green color with hover animation

### 8. Contact Information Section
- WhatsApp contact button
- Google Maps listing link
- Highlighted call-to-action design

### 9. Footer
- Hotel name and address
- Links to booking platforms (Goibibo, MakeMyTrip, JustDial)
- Copyright information

## External Links

### Booking Platforms
- **Goibibo:** https://www.goibibo.com/hotels/maxx-rooms-hotel-in-gurgaon-6493610740515855306/
- **MakeMyTrip:** https://www.makemytrip.com/hotels/maxx_rooms-details-gurgaon.html
- **JustDial:** https://www.justdial.com/Gurgaon/Maxx-Rooms-Sarhaul/011PXX11-XX11-240730160335-R4B9_BZDET

### Google Maps
- **Location URL:** https://www.google.com/maps/place/F3RC%2B7JM+Maxx+Rooms,+near+munjal+company,+Maruti+Udyog,+Sector+18,+Gurugram,+Sarhol,+Haryana+122015

## Design System

### Colors
- **Primary:** #0b6efd (Bright Blue)
- **Background:** #f7f7f8 (Light Gray)
- **Card Background:** #ffffff (White)
- **WhatsApp Green:** #25D366
- **Badge Colors:**
  - Blue: #eef5ff
  - Orange: #fff6ef
  - Green: #eef7ec

### Typography
- **Font Family:** Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial
- **Responsive:** Optimized for mobile and desktop

### Responsive Breakpoints
- **Mobile:** Default (< 1280px)
- **Desktop:** xl breakpoint (≥ 1280px)

## Form Validation

All forms include comprehensive validation:
- Name: Minimum 2 characters
- Phone: Minimum 10 digits
- Dates: Required fields
- Room Type: Must select an option
- Message: Minimum 10 characters

## WhatsApp Message Format

### Booking Request
```
*Booking Request - MAXX Rooms*

*Name:* [User Name]
*Phone:* [User Phone]
*Check-in:* [Date]
*Check-out:* [Date]
*Room Type:* [Deluxe/Superior]
*Special Requests:* [Optional]

Please confirm availability and pricing.
```

### Contact Inquiry
```
*Contact Inquiry - MAXX Rooms*

*Name:* [User Name]
*Phone:* [User Phone]

*Message:*
[User Message]
```

## Technical Stack

- **Framework:** React + TypeScript
- **Styling:** Tailwind CSS
- **UI Components:** shadcn/ui
- **Form Handling:** React Hook Form + Zod validation
- **Icons:** Lucide React
- **Build Tool:** Vite

## Browser Compatibility

The website is fully responsive and compatible with:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Features

- Lazy loading for images
- Optimized image sizes
- Smooth animations and transitions
- Fast form submissions
- Efficient review rotation

## Accessibility

- Semantic HTML elements
- ARIA labels for interactive elements
- Keyboard navigation support
- Screen reader friendly
- High contrast ratios

## Deployment Checklist

Before going live, ensure:
1. ✅ Update WhatsApp number in `src/pages/Home.tsx`
2. ✅ Verify all external links work correctly
3. ✅ Test all forms submit to correct WhatsApp number
4. ✅ Check Google Maps embeds load properly
5. ✅ Test on mobile devices
6. ✅ Verify all images load correctly
7. ✅ Test review rotation functionality
8. ✅ Confirm all booking platform links are correct
